package com.example.hri.proximity_test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.util.Log;
import android.app.Application;

import com.estimote.internal_plugins_api.cloud.CloudCredentials;
import com.estimote.mustard.rx_goodness.rx_requirements_wizard.Requirement;
import com.estimote.mustard.rx_goodness.rx_requirements_wizard.RequirementsWizardFactory;
import com.estimote.proximity_sdk.proximity.EstimoteCloudCredentials;
import com.estimote.proximity_sdk.proximity.ProximityAttachment;
import com.estimote.proximity_sdk.proximity.ProximityObserver;
import com.estimote.proximity_sdk.proximity.ProximityObserverBuilder;
import com.estimote.proximity_sdk.proximity.ProximityZone;

import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    EstimoteCloudCredentials cloudCredentials = new EstimoteCloudCredentials("fibo-hri-proximity-301", "d5b463dadc257cc256285c4a75322a64");
    ProximityObserver proximityObserver = new ProximityObserverBuilder(getApplicationContext(), cloudCredentials)
            .withBalancedPowerMode()
            .withOnErrorAction(new Function1<Throwable, Unit>() {
                @Override
                public Unit invoke(Throwable throwable) {
                    return null;
                }
            })
            .build();
    ProximityZone lab1 =
            proximityObserver.zoneBuilder()
                    .forAttachmentKeyAndValue("room", "research1")
                    .inFarRange()
                    .withOnEnterAction(new Function1<ProximityAttachment, Unit>() {
                        @Override public Unit invoke(ProximityAttachment proximityAttachment) {
                            /* Do something here */
                            Log.d("app", "Welcome");
                            return null;
                        }
                    })
                    .withOnExitAction(new Function1<ProximityAttachment, Unit>() {
                        @Override
                        public Unit invoke(ProximityAttachment proximityAttachment) {
                            /* Do something here */
                            Log.d("app", "Bye");
                            return null;
                        }
                    })
                    .create();


    ProximityObserver.Handler observationHandler =
            proximityObserver
                    .addProximityZone(lab1)
                    .start();


}

